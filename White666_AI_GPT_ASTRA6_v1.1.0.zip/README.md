# White666 AI · GPT ASTRA 6 — v1.1.0

A mobile-first, all-in-one online AI assistant with a responsive web interface and a native Android WebView shell. GPT ASTRA 6 is the assistant persona/system prompt; the underlying model is whichever hosted model you select in OpenRouter. This project does **not** create a new foundation model.

## Included features

- Online AI chat with switchable OpenRouter model IDs. The app can load models listed as free and also accepts a model ID manually.
- GPT ASTRA 6 assistant persona based on the instructions supplied for this project: science, learning, research honesty, programming, creative work, multilingual assistance, and safe technology.
- AI Writer, Coding Lab, fair-play Free Fire coach, file/image assistant, and voice dictation / read-aloud tools (dependent on device/browser support).
- Image generation through OpenRouter's unified Image API. Image model requests usually cost credits.
- Chat export, clear history, and local storage for plain-text conversation history.
- Responsive dark UI, installable web manifest, service worker, and Android WebView app shell.
- No artificial daily-message counter in the app UI. Provider limits and usage costs still apply.

## Important setup and limits

1. The app requires internet access to use online AI.
2. Get your own OpenRouter API key at <https://openrouter.ai/keys>, then open **Settings** in the app and enter it. The key is kept in page memory and is not written to local storage; restarting or refreshing clears it.
3. This is a personal-use starter. Since the client calls OpenRouter directly, your own key is visible to the running app/browser session and should not be shared or embedded as a common key in an app distributed publicly. For a public product, add a secure backend that stores provider secrets server-side and sets authentication, cost limits, and abuse protection.
4. A model listed as free may still have availability, rate, context, or provider-specific restrictions. Image generation is generally paid. The app has no built-in daily cap, but **unlimited usage cannot be guaranteed** by the provider or model.
5. Text/file support includes `.txt`, `.md`, `.csv`, `.json`, `.html`, `.log`, `.png`, `.jpg/.jpeg`, and `.webp`. Files are capped at 10 MB; text is truncated at 50,000 characters. PDF extraction is not included in this version.
6. Voice input requires browser/device speech-recognition support and permission. Read-aloud requires text-to-speech support.
7. Free Fire tools provide fair-play training tips; they do not modify game files or provide cheats.

## Use the web version

Host the `web/` directory on an HTTPS static host, or serve it locally while developing. Example:

```sh
cd web
python -m http.server 8080
```

Then open `http://localhost:8080`. Install-to-home-screen/PWA features work best when deployed over HTTPS. The standalone HTML app requires no bundler.

## Build an Android APK using a phone (no PC required)

The native Android project is in `android/`. It uses Java 17, Android Gradle Plugin 8.13.0, Gradle 8.13, Android SDK 35, and AndroidX WebKit/Core. The container used to prepare this source does not include the Android SDK or Gradle installation, so **no APK binary was built here**. The source and build workflow are provided instead.

### Option A — GitHub Actions from your phone

1. Sign in to GitHub in your phone browser and create an empty repository.
2. Upload the files from this ZIP into the repository, keeping the `.github/workflows/build-apk.yml` path intact.
3. Open **Actions** and run **Build White666 AI APK** (or push to the main/master branch to trigger it).
4. When the run completes, open the run summary and download the `White666-AI-debug-apk` artifact.
5. Extract the artifact and install `app-debug.apk`. Android may ask you to permit installation from the browser or file manager that downloaded it.

The output is a debug APK for personal testing, not a Play Store release. For distribution, create and protect your own signing key and use a release build.

### Option B — AndroidIDE

Use an Android Gradle IDE on your phone that supports Android Gradle Plugin 8.13 and Gradle 8.13. Open the `android/` project, allow it to fetch dependencies, and run `assembleDebug`. IDE support for current build tools may vary; GitHub Actions is usually the more repeatable method.

## Tests

Run the included 10 automated source/configuration checks:

```sh
python tests/test_app.py
```

The checks require Python and Node.js; they cover JavaScript syntax, HTML metadata, GPT ASTRA 6 prompt identity/honesty, response modes, navigation/DOM consistency, API-key persistence, API wiring, Android WebView safety settings, asset consistency, and the build workflow. They do not prove that live OpenRouter access or every selected model works; live requests need a valid key and may incur charges. A UI/browser runner may be blocked by restrictive browser policies in some environments.

## API references

- OpenRouter chat completions: <https://openrouter.ai/docs/api/api-reference/chat/send-chat-completion-request>
- OpenRouter models catalogue: <https://openrouter.ai/docs/api/api-reference/models/get-models>
- OpenRouter image generation guide: <https://openrouter.ai/blog/tutorials/image-generation/>
