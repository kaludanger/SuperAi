"""Automated source/configuration checks for White666 AI / GPT ASTRA 6.

Run: python tests/test_app.py
These checks need Python and Node.js. They do not spend API credits.
Browser interaction tests are intentionally separate because some locked-down CI/browser
policies disable navigation; these checks validate the shipped source and project wiring.
"""
from __future__ import annotations

import re
import subprocess
import unittest
from pathlib import Path
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "web"
HTML = WEB / "index.html"
JS = WEB / "app.js"
SOURCE = JS.read_text(encoding="utf-8")
DOC = (ROOT / "README.md").read_text(encoding="utf-8")


class HtmlAuditParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids = set()
        self.nav_views = set()
        self.section_views = set()
        self.title_parts = []
        self.in_title = False
        self.meta = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "id" in attrs:
            self.ids.add(attrs["id"])
        if tag == "button" and attrs.get("data-view"):
            self.nav_views.add(attrs["data-view"])
        if tag == "section" and attrs.get("class") and "view" in attrs["class"].split():
            section_id = attrs.get("id", "")
            if section_id.startswith("view-"):
                self.section_views.add(section_id.removeprefix("view-"))
        if tag == "title":
            self.in_title = True
        if tag == "meta":
            self.meta.append(attrs)

    def handle_endtag(self, tag):
        if tag == "title":
            self.in_title = False

    def handle_data(self, data):
        if self.in_title:
            self.title_parts.append(data)



class White666SourceTests(unittest.TestCase):
    def test_01_html_metadata_and_responsive_viewport(self):
        parser = HtmlAuditParser()
        parser.feed(HTML.read_text(encoding="utf-8"))
        self.assertIn("GPT ASTRA 6", "".join(parser.title_parts))
        viewport = next((tag for tag in parser.meta if tag.get("name") == "viewport"), None)
        self.assertIsNotNone(viewport)
        self.assertIn("width=device-width", viewport["content"])

    def test_02_javascript_parses_without_syntax_errors(self):
        result = subprocess.run(["node", "--check", str(JS)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_03_astra_identity_and_honesty_are_in_system_prompt(self):
        self.assertIn("You are GPT ASTRA 6", SOURCE)
        self.assertIn("never claim that this persona is a distinct foundation model", SOURCE)
        self.assertIn("never invent facts, data, sources", SOURCE)
        self.assertIn("Never claim code has been run, APKs built", SOURCE)

    def test_04_requested_response_modes_are_present(self):
        for mode in ["ASTRA QUICK", "ASTRA THINK", "ASTRA CODE", "ASTRA RESEARCH", "ASTRA CREATE", "ASTRA TEACH", "ASTRA ANALYZE", "ASTRA BUILDER", "ASTRA EXPERT", "ASTRA SAFE"]:
            self.assertIn(mode, SOURCE)
        for mode_id in ["general", "writer", "coding", "gaming", "file", "voice"]:
            self.assertRegex(SOURCE, rf"\b{mode_id}:\s*['\"]")

    def test_05_navigation_buttons_match_sections(self):
        parser = HtmlAuditParser()
        parser.feed(HTML.read_text(encoding="utf-8"))
        self.assertEqual(parser.nav_views, parser.section_views)
        self.assertEqual(len(parser.nav_views), 7)

    def test_06_javascript_static_ids_exist_in_html(self):
        parser = HtmlAuditParser()
        parser.feed(HTML.read_text(encoding="utf-8"))
        html_ids = parser.ids
        script_ids = set(re.findall(r"\$\('([A-Za-z][A-Za-z0-9_-]*)'\)", SOURCE))
        missing = sorted(script_ids - html_ids - {"typingIndicator"})
        self.assertEqual(missing, [], f"JavaScript references missing HTML IDs: {missing}")

    def test_07_api_key_is_not_written_to_local_storage(self):
        self.assertIn("state.apiKey = key", SOURCE)
        self.assertIn("'Authorization': `Bearer ${state.apiKey}`", SOURCE)
        self.assertIn("localStorage.setItem(HISTORY_KEY", SOURCE)
        self.assertNotRegex(SOURCE, r"localStorage\.(?:setItem|getItem)\([^\n]*(?:apiKey|API_KEY|sk-or)")
        self.assertIn("key stays in app memory", HTML.read_text(encoding="utf-8"))

    def test_08_chat_and_image_api_routes_are_wired(self):
        self.assertIn("https://openrouter.ai/api/v1/chat/completions", SOURCE)
        self.assertIn("https://openrouter.ai/api/v1/images", SOURCE)
        self.assertIn("JSON.stringify({ model: model.trim() || 'openrouter/free'", SOURCE)
        self.assertIn("aspect_ratio: $('imageAspect').value", SOURCE)
        self.assertIn("data?.choices?.[0]?.message?.content", SOURCE)
        self.assertIn("data?.data?.[0]", SOURCE)

    def test_09_android_shell_has_basic_webview_safety_settings(self):
        manifest = (ROOT / "android/app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
        activity = (ROOT / "android/app/src/main/java/com/white666/ai/MainActivity.java").read_text(encoding="utf-8")
        build = (ROOT / "android/app/build.gradle").read_text(encoding="utf-8")
        self.assertIn('android.permission.INTERNET', manifest)
        self.assertIn('android:usesCleartextTraffic="false"', manifest)
        self.assertIn("settings.setAllowFileAccess(false)", activity)
        self.assertIn("WebViewAssetLoader", activity)
        self.assertIn("versionName '1.1.0'", build)

    def test_10_android_assets_build_workflow_and_usage_docs(self):
        asset_root = ROOT / "android/app/src/main/assets"
        for name in ["index.html", "styles.css", "app.js", "sw.js", "manifest.webmanifest", "icon.svg"]:
            self.assertEqual((WEB / name).read_bytes(), (asset_root / name).read_bytes(), name)
        workflow = ROOT / ".github/workflows/build-apk.yml"
        self.assertTrue(workflow.exists())
        workflow_text = workflow.read_text(encoding="utf-8")
        self.assertIn("assembleDebug", workflow_text)
        self.assertIn("White666-AI-debug-apk", workflow_text)
        self.assertIn("unlimited usage cannot be guaranteed", DOC)
        self.assertIn("Android APK", DOC)


if __name__ == "__main__":
    unittest.main(verbosity=2)
